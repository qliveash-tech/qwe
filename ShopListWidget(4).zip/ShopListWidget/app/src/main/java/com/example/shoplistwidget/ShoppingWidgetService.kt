package com.example.shoplistwidget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class ShoppingWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        ItemsFactory(applicationContext)
}

class ItemsFactory(private val context: Context) : RemoteViewsService.RemoteViewsFactory {

    private var items: List<ShoppingItem> = emptyList()

    override fun onCreate() {}

    override fun onDataSetChanged() {
        items = ShoppingListManager.getItems(context)
    }

    override fun getViewAt(position: Int): RemoteViews {
        val item = items[position]
        val views = RemoteViews(context.packageName, R.layout.widget_list_item)

        views.setTextViewText(R.id.widgetItemText, item.name)
        // куплено — зелёный текст, не куплено — красный
        views.setTextColor(
            R.id.widgetItemText,
            if (item.bought) Color.parseColor("#2E7D32") else Color.parseColor("#C62828")
        )

        // При нажатии шлём broadcast с id товара
        val fillIn = Intent().putExtra(ShoppingWidget.EXTRA_ITEM_ID, item.id)
        views.setOnClickFillInIntent(R.id.widgetItemText, fillIn)

        return views
    }

    override fun getCount() = items.size
    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount() = 1
    override fun getItemId(position: Int) = items[position].id.hashCode().toLong()
    override fun hasStableIds() = true
    override fun onDestroy() {}
}
