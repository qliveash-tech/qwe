package com.example.shoplistwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

class ShoppingWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) updateWidget(context, manager, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        // Обработка нажатия на элемент внутри виджета
        if (intent.action == ACTION_TOGGLE) {
            val itemId = intent.getStringExtra(EXTRA_ITEM_ID)
            if (itemId != null) ShoppingListManager.toggleItem(context, itemId)
            updateAll(context)
        }
        if (intent.action == ACTION_OPEN_APP) {
            context.startActivity(
                Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.shoplistwidget.TOGGLE"
        const val ACTION_OPEN_APP = "com.example.shoplistwidget.OPEN_APP"
        const val EXTRA_ITEM_ID = "item_id"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ShoppingWidget::class.java))
            for (id in ids) updateWidget(context, manager, id)
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.shopping_widget)

            // Заголовок — открывает приложение
            val openIntent = Intent(context, ShoppingWidget::class.java).setAction(ACTION_OPEN_APP)
            views.setOnClickPendingIntent(
                R.id.widgetHeader,
                PendingIntent.getBroadcast(
                    context, 0, openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )

            // Кнопка «+» — открывает приложение для добавления товара
            views.setOnClickPendingIntent(
                R.id.widgetAddButton,
                PendingIntent.getBroadcast(
                    context, 1, openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )

            // Список товаров внутри виджета
            val serviceIntent = Intent(context, ShoppingWidgetService::class.java)
            views.setRemoteAdapter(R.id.widgetList, serviceIntent)

            // Нажатие на элемент списка → переключить «куплено»
            val templateIntent = Intent(context, ShoppingWidget::class.java).setAction(ACTION_TOGGLE)
            views.setPendingIntentTemplate(
                R.id.widgetList,
                PendingIntent.getBroadcast(
                    context, 2, templateIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
            )

            manager.notifyAppWidgetViewDataChanged(widgetId, R.id.widgetList)
            manager.updateAppWidget(widgetId, views)
        }
    }
}
