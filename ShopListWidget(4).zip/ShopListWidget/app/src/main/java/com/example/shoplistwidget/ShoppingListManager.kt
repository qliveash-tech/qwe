package com.example.shoplistwidget

import android.content.Context
import android.content.Intent
import androidx.localbroadcastmanager.content.LocalBroadcastManager

data class ShoppingItem(
    val id: String,
    val name: String,
    val bought: Boolean
)

object ShoppingListManager {

    private const val PREFS = "shopping_prefs"
    private const val KEY_ITEMS = "items"
    const val ACTION_LIST_CHANGED = "com.example.shoplistwidget.LIST_CHANGED"

    // Формат хранения: id|bought|текст  (текст без символов "|" и "\n")
    private fun encode(item: ShoppingItem): String =
        "${'$'}{item.id}|${'$'}{if (item.bought) "1" else "0"}|${'$'}{item.name.replace("|", "/").replace("\n", " ")}"

    private fun decode(raw: String): ShoppingItem? {
        val parts = raw.split("|", limit = 3)
        if (parts.size < 3) return null
        return ShoppingItem(
            id = parts[0],
            bought = parts[1] == "1",
            name = parts[2]
        )
    }

    fun getItems(context: Context): List<ShoppingItem> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_ITEMS, emptySet())
            ?.mapNotNull { decode(it) }
            ?.sortedBy { it.bought }   // сначала не купленные, потом купленные
            ?: emptyList()
    }

    fun addItem(context: Context, name: String) {
        if (name.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY_ITEMS, mutableSetOf())!!.toMutableSet()
        val item = ShoppingItem(id = System.currentTimeMillis().toString(), name = name.trim(), bought = false)
        set.add(encode(item))
        prefs.edit().putStringSet(KEY_ITEMS, set).apply()
        notifyChanged(context)
    }

    fun toggleItem(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY_ITEMS, mutableSetOf())!!.toMutableSet()
        val newSet = set.map { raw ->
            val item = decode(raw)
            if (item != null && item.id == id) encode(item.copy(bought = !item.bought)) else raw
        }.toMutableSet()
        prefs.edit().putStringSet(KEY_ITEMS, newSet).apply()
        notifyChanged(context)
    }

    fun removeItem(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY_ITEMS, mutableSetOf())!!.toMutableSet()
        set.removeAll { raw -> decode(raw)?.id == id }
        prefs.edit().putStringSet(KEY_ITEMS, set).apply()
        notifyChanged(context)
    }

    private fun notifyChanged(context: Context) {
        LocalBroadcastManager.getInstance(context)
            .sendBroadcast(Intent(ACTION_LIST_CHANGED))
    }
}
