package com.example.shoplistwidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: ItemsAdapter
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            adapter.refresh(ShoppingListManager.getItems(this@MainActivity))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.recycler)
        val input = findViewById<EditText>(R.id.editText)
        val addBtn = findViewById<ImageButton>(R.id.addButton)

        adapter = ItemsAdapter(
            onClick = { item -> ShoppingListManager.toggleItem(this, item.id) },
            onLongClick = { item ->
                AlertDialog.Builder(this)
                    .setMessage("Удалить «${'$'}{item.name}»?")
                    .setPositiveButton("Удалить") { _, _ ->
                        ShoppingListManager.removeItem(this, item.id)
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
                true
            }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        addBtn.setOnClickListener {
            ShoppingListManager.addItem(this, input.text.toString())
            input.text.clear()
        }

        adapter.refresh(ShoppingListManager.getItems(this))
    }

    override fun onResume() {
        super.onResume()
        LocalBroadcastManager.getInstance(this).registerReceiver(
            receiver, IntentFilter(ShoppingListManager.ACTION_LIST_CHANGED)
        )
        adapter.refresh(ShoppingListManager.getItems(this))
    }

    override fun onPause() {
        super.onPause()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver)
    }
}

class ItemsAdapter(
    private val onClick: (ShoppingItem) -> Unit,
    private val onLongClick: (ShoppingItem) -> Boolean
) : RecyclerView.Adapter<ItemsAdapter.VH>() {

    private var items: List<ShoppingItem> = emptyList()

    fun refresh(newItems: List<ShoppingItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false)
        return VH(view)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.text.text = item.name
        // куплено — зелёный, не куплено — красный
        holder.text.setTextColor(
            holder.text.context.getColor(if (item.bought) R.color.bought_green else R.color.not_bought_red)
        )
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item) }
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.itemText)
    }
}
